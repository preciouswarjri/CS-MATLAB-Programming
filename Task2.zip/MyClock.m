clc;
clear all;
close all;

figure('name','Analog Clock', ...
    'color',[1 1 1], 'WindowButtonDownFcn', @clockClick);
axis('off');

% Draw the Clo
plot(12*cosd(0:360), 12*sind(0:360),'y' ,'linewidth',6);hold on
fill(11.8*cosd(0:360),11.8*sind(0:360),[0.9 0.9 0.9]);
fill(cosd(0:360),sind(0:360),'w');

% Drawing numbers
for n=1:12
    text(-8.5*cosd(90+n*360/12), 8.5*sind(90+n*360/12),num2str(n));
    plot([9.5 11]*cosd(90+n*360/12),[9.5 11]*sind(90+n*360/12),'k', 'linewidth',2);
    for nn=1:4
        plot([9.9 11]*cosd(90+n*360/12+nn*6),[9.9 11]*sind(90+n*360/12+nn*6),'k','linewidth', 1)
    end
end

global hp;
global mp;
global sp;

% Movement and drawing hands
sp=[]; mp=[]; hp=[];
while(3)
    time = fix(clock);
    hs = 90+time(6)*6;
    hm = 90+time(5)*6+time(6)/10;
    hh = 90+time(4)*30+time(5)/2;
    delete(hp), hp=plot([0 -7.5*cosd(hh)],[0 7.5*sind(hh)],'r','LineWidth',2);
    delete(mp), mp=plot([0 -9*cosd(hm)],[0 9*sind(hm)],'b','linewidth', 1.5);
    delete(sp); sp= plot([0 -10*cosd(hs)],[0 10*sind(hs)],'black','linewidth', 1);
    pause(1);
end

function clockClick(hObject, eventdata)
    global hp;
    global mp;
    global sp;
    % Get new time from user
    newTime = inputdlg({'Enter new hours:', 'Enter new minutes:', 'Enter new seconds:'}, 'Set Time');
    
    if ~isempty(newTime)
        newHours = str2double(newTime{1});
        newMinutes = str2double(newTime{2});
        newSeconds = str2double(newTime{3});
        
   
        system(['date ', datestr(now, 'mm-dd-yy'), ' ', ...  % Include current date
         num2str(newHours), ':', num2str(newMinutes), ':', num2str(newSeconds)]);

        % Update clock hands
        set(hp, 'XData', [0 -7.5*cosd(90 + newHours*30 + newMinutes/2)], 'YData', [0 7.5*sind(90 + newHours*30 + newMinutes/2)]);
        set(mp, 'XData', [0 -9*cosd(90 + newMinutes*6 + newSeconds/10)], 'YData', [0 9*sind(90 + newMinutes*6 + newSeconds/10)]);
        set(sp, 'XData', [0 -10*cosd(90 + newSeconds*6)], 'YData', [0 10*sind(90 + newSeconds*6)]);
        pause(2);
        disp('Clicked') 
    end
end
